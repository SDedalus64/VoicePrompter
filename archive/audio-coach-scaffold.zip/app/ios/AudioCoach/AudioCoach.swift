import Foundation
import AVFoundation
import React

@objc(AudioCoach)
class AudioCoach: RCTEventEmitter {
  private let session = AVAudioSession.sharedInstance()
  private var engine = AVAudioEngine()
  private var plan: SessionPlan?

  struct SessionPlan: Codable { let id: String; let title: String; let segments: [Segment]; let policy: Policy }
  struct Segment: Codable {
    let id, title: String
    let keyPoints: [String]
    let promptType: String
    let targetSecs: Int
    let toleranceSecs: Int?
    let minGapMs: Int
    let cueStyle: String
    let priority: Int
    let promptText: String?
  }
  struct Policy: Codable {
    let interruptMode: String
    let maxRambleSecs: Int
    let fallbackCueText: String?
    let preRollToneMs: Int
    let asrEnabled: Bool
    let ttsVoiceId: String?
  }

  override static func requiresMainQueueSetup() -> Bool { true }
  override func supportedEvents() -> [String]! { ["AudioCoachEvent"] }

  @objc func startSession(_ planJson: NSString,
                          resolver resolve: RCTPromiseResolveBlock,
                          rejecter reject: RCTPromiseRejectBlock) {
    do {
      try session.setCategory(.playAndRecord, options: [.defaultToSpeaker, .allowBluetooth, .mixWithOthers])
      try session.setActive(true)

      if engine.isRunning { engine.stop() }
      engine = AVAudioEngine()

      // VAD input tap (placeholder)
      let input = engine.inputNode
      let bus = 0
      let format = input.outputFormat(forBus: bus)
      input.installTap(onBus: bus, bufferSize: 1024, format: format) { _, _ in
        // TODO: VAD / silence detection
      }

      if let data = (planJson as String).data(using: .utf8) {
        self.plan = try JSONDecoder().decode(SessionPlan.self, from: data)
      }

      try engine.start()
      sendStatus("engine_started")

      // Naive: schedule first cue after 2s (replace with native scheduler + VAD gaps)
      DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
        self?.playToneThenTTS(text: "Introduce the challenge: selling a service = selling trust.")
      }

      resolve(nil)
    } catch {
      reject("start_failed", error.localizedDescription, error)
    }
  }

  @objc func stopSession(_ resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    engine.stop()
    do { try session.setActive(false) } catch {}
    sendStatus("engine_stopped")
    resolve(nil)
  }

  private func sendStatus(_ msg: String) {
    sendEvent(withName: "AudioCoachEvent", body: ["type":"status","message":msg])
  }

  private func playToneThenTTS(text: String) {
    sendStatus("cue_tone")
    // TODO: generate & play a short tone via AVAudioPlayerNode
    // TODO: call TTS (AVSpeechSynthesizer for MVP; switch to Azure later)
    sendEvent(withName: "AudioCoachEvent", body: ["type":"cue","message":text])
  }
}
