package com.audiocoach

import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule.RCTDeviceEventEmitter
import android.os.Handler
import android.os.Looper

class AudioCoachModule(reactContext: ReactApplicationContext) :
  ReactContextBaseJavaModule(reactContext) {

  private val handler = Handler(Looper.getMainLooper())
  private var isRunning = false

  override fun getName() = "AudioCoach"

  @ReactMethod
  fun startSession(planJson: String, promise: Promise) {
    isRunning = true
    send("status", "engine_started")
    handler.postDelayed({
      if (!isRunning) return@postDelayed
      send("cue", "Introduce the challenge: selling a service = selling trust.")
    }, 2000)
    promise.resolve(null)
  }

  @ReactMethod
  fun stopSession(promise: Promise) {
    isRunning = false
    send("status", "engine_stopped")
    promise.resolve(null)
  }

  private fun send(type: String, msg: String) {
    val params = Arguments.createMap().apply {
      putString("type", type)
      putString("message", msg)
    }
    reactApplicationContext
      .getJSModule(RCTDeviceEventEmitter::class.java)
      .emit("AudioCoachEvent", params)
  }
}
