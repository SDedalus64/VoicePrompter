// placeholder for Azure streaming ASR glue
export async function startAzureStream() {
  // TODO: wire WebSocket to Azure Speech SDK
  return;
}
