// placeholder for LLM-powered segue generation
export async function generateSegue(currentTitle: string, nextTitle: string, transcript: string): Promise<string> {
  // TODO: call your LLM endpoint with current context
  return `Quick segue from "${currentTitle}" to "${nextTitle}"`;
}
